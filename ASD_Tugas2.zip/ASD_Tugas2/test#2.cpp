#include <iostream>
#include <sstream>
using namespace std;

// Forward declaration
struct User;
struct followNode;
struct Group;

// User struct definition
struct User {
    string username;
    string minat[3];
    User *nextMember;
    followNode* headFollower;
    followNode* headFollowing;
    int followerCount, followingCount;
    User(stringstream &ss, string name) {
        username = name;
        ss >> minat[0] >> minat[1] >> minat[2];
        nextMember = nullptr;
        headFollower = nullptr;
        headFollowing = nullptr;
        followerCount = 0;
        followingCount = 0;
    }
};

// FollowNode struct definition
struct followNode {
    User* user;
    followNode* next;

    followNode(User* newUser) : user(newUser), next(nullptr) {}
};

// Group struct definition
struct Group {
    User* headMember = nullptr;
    User* tailMember = nullptr;
    Group* nextGroup = nullptr;
    int group_id;
    Group(User*& newUser, int id) {
        if (headMember == nullptr) {
            headMember = newUser;
            tailMember = newUser;
            group_id = id;
        } else {
            tailMember->nextMember = newUser;
            tailMember = newUser;
            group_id = id;
        }
    }
};

// app struct definition
struct app {
    Group* headGroup = nullptr;
    Group* tailGroup = nullptr;
    int groupCounter = 0;
    int numberOfGroup = 0;

    // Function to insert a new user into the app
    void insert(stringstream &ss, string name) {
        groupCounter++;
        User* newUser = new User(ss, name);
        Group* newGroup = new Group(newUser, groupCounter);
        if (headGroup == nullptr) {
            headGroup = newGroup;
            tailGroup = newGroup;
        } else {
            tailGroup->nextGroup = newGroup;
            tailGroup = newGroup;
        }
        numberOfGroup++;
    }

    // Function to find a group by username
    Group* findGroup(string username) {
        Group* currentGroup = headGroup;
        while (currentGroup) {
            User* currentUser = currentGroup->headMember;
            while (currentUser) {
                if (currentUser->username == username) {
                    return currentGroup;
                }
                currentUser = currentUser->nextMember;
            }
            currentGroup = currentGroup->nextGroup;
        }
        return nullptr;
    }

    // Function to find a user by username
    User* findUser(string username) {
        Group* currentGroup = headGroup;
        while (currentGroup) {
            User* currentUser = currentGroup->headMember;
            while (currentUser) {
                if (currentUser->username == username) {
                    return currentUser;
                }
                currentUser = currentUser->nextMember;
            }
            currentGroup = currentGroup->nextGroup;
        }
        return nullptr;
    }

    // Function to connect two users
    void connect(string user1, string user2) {
        Group* yangFollow_Group = findGroup(user1);
        Group* diFollow_Group = findGroup(user2);

        User* yangFollow = findUser(user1);
        User* diFollow = findUser(user2);

        followNode* folower = new followNode(yangFollow);
        folower->next = diFollow->headFollower;
        diFollow->headFollower = folower;
        diFollow->followerCount += 1;

        followNode* following = new followNode(diFollow);
        following->next = yangFollow->headFollowing;
        yangFollow->headFollowing = following;
        yangFollow->followingCount += 1;

        if (diFollow_Group->group_id == yangFollow_Group->group_id) { //SYARAT :: dalam group yang sama
            return;
        } else {
            yangFollow_Group->tailMember->nextMember = diFollow_Group->headMember;
            yangFollow_Group->tailMember = diFollow_Group->tailMember;

            if (headGroup == diFollow_Group) {
                headGroup = diFollow_Group->nextGroup;
            } else {
                Group* prevGroup = headGroup;
                while (prevGroup && prevGroup->nextGroup != diFollow_Group) {
                    prevGroup = prevGroup->nextGroup;
                }

                if (tailGroup == diFollow_Group) {
                    tailGroup = prevGroup;
                } else {
                    prevGroup->nextGroup = diFollow_Group->nextGroup;
                }
            }
            delete diFollow_Group;
            numberOfGroup--;
        }
    }

    // Function to print a group's members
    void printGroup(int groupID) {
        Group* currentGroup = headGroup;
        while (currentGroup) {
            if (currentGroup->group_id == groupID) {
                User* currentUser = currentGroup->headMember;
                cout << "Group ID: " << currentGroup->group_id << endl;
                while (currentUser) {
                    cout << "Username: " << currentUser->username << ", Minat: "
                         << currentUser->minat[0] << ", " << currentUser->minat[1] << ", " << currentUser->minat[2] << endl;
                    currentUser = currentUser->nextMember;
                }
                return;
            }
            currentGroup = currentGroup->nextGroup;
        }
        cout << "Group with ID " << groupID << " not found." << endl;
    }
};

// Main function
int main() {
    app myApp;

    // Inserting users
    stringstream ss1("interest1 interest2 interest3");
    myApp.insert(ss1, "user1");

    stringstream ss2("interest4 interest5 interest6");
    myApp.insert(ss2, "user2");

    stringstream ss3("interest7 interest8 interest9");
    myApp.insert(ss3, "user3");

    stringstream ss4("interest10 interest11 interest12");
    myApp.insert(ss4, "user4");

    stringstream ss5("interest13 interest14 interest15");
    myApp.insert(ss5, "user5");

    stringstream ss6("interest16 interest17 interest18");
    myApp.insert(ss6, "user6");

    // Connecting users
    myApp.connect("user1", "user2");
    myApp.connect("user3", "user2");

    // Printing a group
    int groupID = 3; // Example group ID
    cout << "Printing Group with ID " << groupID << ":" << endl;
    myApp.printGroup(groupID);

    return 0;
}
