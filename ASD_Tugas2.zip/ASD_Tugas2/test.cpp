#include <iostream>
#include <string>
#include <cstring>

const int TABLE_SIZE = 100; // Hash table size
const int MAX_HOBBIES = 10; // Maximum number of hobbies per user

struct UserNode; // Forward declaration

struct FollowerNode {
    UserNode* user; // Pointer to the UserNode instead of username
    FollowerNode* next;

    FollowerNode(UserNode* userNode) : user(userNode), next(nullptr) {}
};

struct UserNode {
    std::string username;
    FollowerNode* followerHead;
    UserNode* next;
    std::string hobbies[MAX_HOBBIES];
    int hobbyCount;

    UserNode(const std::string& name) : username(name), followerHead(nullptr), next(nullptr), hobbyCount(0) {}

    void addHobby(const std::string& hobby) {
        if (hobbyCount < MAX_HOBBIES) {
            hobbies[hobbyCount++] = hobby;
        } else {
            std::cout << "Hobby list is full for user " << username << ".\n";
        }
    }
};

class HashTable {
private:
    UserNode* table[TABLE_SIZE];

    int hashFunction(const std::string& username) const {
        int hash = 0;
        for (char ch : username) {
            hash = (hash * 31 + ch) % TABLE_SIZE;
        }
        return hash;
    }

public:
    HashTable() {
        std::memset(table, 0, sizeof(table));
    }

    ~HashTable() {
        for (int i = 0; i < TABLE_SIZE; ++i) {
            UserNode* user = table[i];
            while (user) {
                FollowerNode* follower = user->followerHead;
                while (follower) {
                    FollowerNode* temp = follower;
                    follower = follower->next;
                    delete temp;
                }
                UserNode* temp = user;
                user = user->next;
                delete temp;
            }
        }
    }

    void addUser(const std::string& username) {
        int index = hashFunction(username);
        UserNode* newUser = new UserNode(username);
        newUser->next = table[index];
        table[index] = newUser;
        std::cout << "User " << username << " added.\n";
    }

    UserNode* findUser(const std::string& username) {
        int index = hashFunction(username);
        UserNode* user = table[index];
        while (user && user->username != username) {
            user = user->next;
        }
        return user;
    }

    void addHobby(const std::string& username, const std::string& hobby) {
        UserNode* user = findUser(username);
        if (user) {
            user->addHobby(hobby);
            std::cout << "Hobby " << hobby << " added to user " << username << ".\n";
        } else {
            std::cout << "User " << username << " does not exist.\n";
        }
    }

    void follow(const std::string& follower, const std::string& followee) {
        UserNode* followerNode = findUser(follower);
        UserNode* followeeNode = findUser(followee);

        if (followerNode && followeeNode) {
            FollowerNode* newFollower = new FollowerNode(followeeNode);
            newFollower->next = followerNode->followerHead;
            followerNode->followerHead = newFollower;
            std::cout << follower << " now follows " << followee << ".\n";
        } else {
            std::cout << "Either " << follower << " or " << followee << " does not exist.\n";
        }
    }

    void printGraph() const {
        for (int i = 0; i < TABLE_SIZE; ++i) {
            UserNode* user = table[i];
            while (user) {
                std::cout << user->username << " follows: ";
                FollowerNode* follower = user->followerHead;
                while (follower) {
                    std::cout << follower->user->username << " "; // Access the username via pointer
                    follower = follower->next;
                }
                std::cout << "\nHobbies: ";
                for (int j = 0; j < user->hobbyCount; ++j) {
                    std::cout << user->hobbies[j] << " ";
                }
                std::cout << std::endl;
                user = user->next;
            }
        }
    }
};

int main() {
    HashTable socialNetwork;

    socialNetwork.addUser("Alice");
    socialNetwork.addUser("Bob");
    socialNetwork.addUser("Charlie");

    socialNetwork.addHobby("Alice", "Reading");
    socialNetwork.addHobby("Alice", "Traveling");
    socialNetwork.addHobby("Bob", "Cooking");
    socialNetwork.addHobby("Charlie", "Gaming");

    socialNetwork.follow("Alice", "Bob");
    socialNetwork.follow("Alice", "Charlie");
    socialNetwork.follow("Bob", "Charlie");

    socialNetwork.printGraph();

    return 0;
}
