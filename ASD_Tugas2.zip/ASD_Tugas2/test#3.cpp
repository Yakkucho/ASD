#include <iostream>
#include <sstream>
using namespace std;

struct User;

struct followNode {
    User* user;
    followNode* next;
    followNode(User* newUser) : user(newUser), next(nullptr) {}
};

struct User {
    string username;
    string minat[3];
    User *nextMember;
    followNode* headFollower;
    followNode* headFollowing;
    int followerCount,followingCount;
    User(stringstream &ss,string name){
        username = name;
        ss >> minat[0] >> minat[1] >> minat[2];
        nextMember = nullptr;
        headFollower = nullptr;
        headFollowing = nullptr;
        followerCount = 0;
        followingCount = 0;
    }
};

struct Group
{
    User* headMember = nullptr;
    User* tailMember = nullptr;
    Group* nextGroup = nullptr;
    int group_id;
    Group(User*& newUser,int id){
        if (headMember == nullptr){
            headMember = newUser;
            tailMember = newUser;
            group_id = id;            
        } else {
            tailMember->nextMember = newUser;
            tailMember = newUser;
            group_id = id;
        }
    }
};

struct nodeKata {
    string data;
    nodeKata* next;
    int rankMinat;

    nodeKata(string newData) : data(newData), next(nullptr), rankMinat(1) {}
    
};

struct textOutputContainer {
    nodeKata* headData = nullptr;
    nodeKata* tailData = nullptr;
    nodeKata* headMinat = nullptr;

    ~textOutputContainer() {
        while (headData != nullptr) {
            nodeKata* temp = headData;
            headData = headData->next;
            delete temp;
        }
    }

    void addString(string newData, int type) {
        switch (type) {
            case 1: {
                nodeKata* newKata1 = new nodeKata(newData);
                if (headData == nullptr) {
                    headData = newKata1;
                    tailData = newKata1;
                } else {
                    tailData->next = newKata1;
                    tailData = newKata1;
                }
                break;
            }
            case 2: {
                nodeKata* current = headData;
                while (current != nullptr) {
                    if (current->data == newData) {
                        return;
                    }
                    current = current->next;
                }

                nodeKata* newKata2 = new nodeKata(newData);
                if (headData == nullptr) {
                    headData = newKata2;
                    tailData = newKata2;
                } else {
                    tailData->next = newKata2;
                    tailData = newKata2;
                }
                break;
            }
            case 3: {
                nodeKata* current = headMinat;
                while (current != nullptr) {
                    if (current->data == newData) {
                        current->rankMinat += 1;
                        return;
                    }
                    current = current->next;
                }

                nodeKata* newKata3 = new nodeKata(newData);
                if (headMinat == nullptr) {
                    headMinat = newKata3;
                } else {
                    newKata3->next = headMinat;
                    headMinat = newKata3;
                }
                break;
            }
            default:
                break;
        }
    }

    nodeKata* merge(nodeKata* left, nodeKata* right) {
        nodeKata dummyHead("dummy");
        nodeKata* tail = &dummyHead;

        while (left != nullptr && right != nullptr) {
            if (left->data <= right->data) {
                tail->next = left;
                left = left->next;
            } else {
                tail->next = right;
                right = right->next;
            }
            tail = tail->next;
        }

        tail->next = (left != nullptr) ? left : right;
        return dummyHead.next;
    }

    nodeKata* mergeSort(nodeKata* head) {
        if (head == nullptr || head->next == nullptr)
            return head;

        nodeKata* slow = head;
        nodeKata* fast = head->next;

        while (fast != nullptr && fast->next != nullptr) {
            slow = slow->next;
            fast = fast->next->next;
        }

        nodeKata* mid = slow->next;
        slow->next = nullptr;

        return merge(mergeSort(head), mergeSort(mid));
    }

    void sortText() {
        headData = mergeSort(headData);
    }

    void addMinat(nodeKata*& minat){
        if (headMinat == nullptr){
            headMinat = minat;
        } else {
            minat->next = headMinat;
            headMinat = minat;
        }
    }

    void sortMinat(){
        int highestMinat = -1;
        nodeKata* temp = headMinat;
        while(temp){
            if (highestMinat < temp->rankMinat){
                highestMinat = temp->rankMinat;
                headData = nullptr;
                addString(temp->data,1);
            } else if (highestMinat == temp->rankMinat){
                addString(temp->data,1);
            }
            temp = temp->next;
        }
    }

    void printText(){
        nodeKata* current = headData;
        while (current != nullptr){
            cout << current->data;
            if (current->next != nullptr){
                cout << ',';
            }
            current = current->next;
        }
        cout << endl;
    }
};


struct app {
    Group* headGroup = nullptr;
    Group* tailGroup = nullptr;
    int groupCounter = 0;
    int numberOfGroup = 0;

    void insert(stringstream &ss,string name){
        groupCounter++;
        User* newUser = new User(ss,name);
        Group* newGroup = new Group(newUser,groupCounter);
        if (headGroup == nullptr){
            headGroup = newGroup;
            tailGroup = newGroup;
        } else {
            tailGroup->nextGroup = newGroup;
            tailGroup = newGroup;        
        }
        numberOfGroup++;
    }

    Group* findGroup(string username){
        Group* currentGroup = headGroup;
        while(currentGroup){
            User* currentUser = currentGroup->headMember;
            while(currentUser){
                if (currentUser->username == username){
                    return currentGroup;
                }
                currentUser = currentUser->nextMember;
            }
            currentGroup = currentGroup->nextGroup;
        }
        return nullptr;
    }

    User* findUser(string username){
        Group* currentGroup = headGroup;
        while(currentGroup){
            User* currentUser = currentGroup->headMember;
            while(currentUser){
                if (currentUser->username == username){
                    return currentUser;
                }
                currentUser = currentUser->nextMember;
            }
            currentGroup = currentGroup->nextGroup;
        }
        return nullptr;
    }

    void connect(string user1, string user2){
        Group* yangFollow_Group = findGroup(user1);
        Group* diFollow_Group = findGroup(user2);
        
        User* yangFollow = findUser(user1);
        User* diFollow = findUser(user2);
        
        followNode* folower = new followNode(yangFollow);
        folower->next = diFollow->headFollower;
        diFollow->headFollower = folower;
        diFollow->followerCount += 1;

        followNode* following = new followNode(diFollow);
        following->next = yangFollow->headFollowing;
        yangFollow->headFollowing = following;
        yangFollow->followingCount += 1;

        if(diFollow_Group->group_id == yangFollow_Group->group_id){ //SYARAT :: dalam group yang sama 
            return;
        } else {
            yangFollow_Group->tailMember->nextMember = diFollow_Group->headMember;
            yangFollow_Group->tailMember = diFollow_Group->tailMember;

            if (headGroup == diFollow_Group){
                headGroup = diFollow_Group->nextGroup;
            } else {
                Group* prevGroup = headGroup;
                while(prevGroup && prevGroup->nextGroup != diFollow_Group){
                    prevGroup = prevGroup->nextGroup;
                }

                if (tailGroup == diFollow_Group){
                    tailGroup = prevGroup;
                } else {
                    prevGroup->nextGroup = diFollow_Group->nextGroup;
                }
            }
            delete diFollow_Group;
            numberOfGroup--;

        }

    }

    void numgroup(){
        cout << numberOfGroup << endl;
    }

    void mostfollowed() {
    int highestFollower = -1;
    textOutputContainer obj;

    Group* currentGroup = headGroup;
    while (currentGroup != nullptr) { // Ensure currentGroup is not null
        User* currentUser = currentGroup->headMember;
        while (currentUser != nullptr) { // Ensure currentUser is not null
            // Add debug print statements to check values
            cout << "Checking user: " << currentUser->username << " with " << currentUser->followerCount << " followers." << endl;
            
            if (highestFollower < currentUser->followerCount) {
                highestFollower = currentUser->followerCount;
                obj.headData = nullptr; // Clear previous results
                obj.addString(currentUser->username, 1);
            } else if (highestFollower == currentUser->followerCount) {
                obj.addString(currentUser->username, 1);
            }
            currentUser = currentUser->nextMember; // Move to the next user
        }
        currentGroup = currentGroup->nextGroup; // Move to the next group
    }

    obj.sortText();
    obj.printText();
}

    void suggestfriend(string username){
        textOutputContainer obj;
        User* user1 = findUser(username);
        followNode* currentFollowing = user1->headFollowing;
        while(currentFollowing){
            User* friends = findUser(currentFollowing->user->username);
            followNode* followerFriends = friends->headFollower;
            while(followerFriends){
                obj.addString(followerFriends->user->username,2);
                followerFriends = followerFriends->next;
            }
            followNode* followingFriends = friends->headFollowing;
            while(followerFriends){
                obj.addString(followingFriends->user->username,2);
                followingFriends = followingFriends->next;
            }
            currentFollowing = currentFollowing->next;

        }
        obj.sortText();
        obj.printText();
    }

    void grouptopic(){
        Group* currentGroup = headGroup;
        while(currentGroup){
            textOutputContainer obj;
            User* currentUser = currentGroup->headMember;
            while(currentUser){
                for (int i = 0;i < 3;i++){
                    obj.addString(currentUser->minat[i],3);
                }
                currentUser = currentUser->nextMember;
            }
            obj.sortMinat();
            obj.sortText();
            obj.printText();
            currentGroup = currentGroup->nextGroup;
        }
    }
};


int main() {
    app myApp;

    // Adding some users and groups
    stringstream ss1("coding music sports");
    stringstream ss2("cooking traveling reading");
    stringstream ss3("music coding movies");
    stringstream ss4("sports cooking movies");
    stringstream ss5("coding reading traveling");

    myApp.insert(ss1, "Alice");
    myApp.insert(ss2, "Bob");
    myApp.insert(ss3, "Charlie");
    myApp.insert(ss4, "Dave");
    myApp.insert(ss5, "Eve");

    // Connect users
    myApp.connect("Alice", "Bob");
    myApp.connect("Alice", "Charlie");
    myApp.connect("Bob", "Dave");
    myApp.connect("Charlie", "Eve");

    // Print number of groups
    myApp.numgroup();

    // Find the most followed user(s)
    cout << "Most followed user(s): ";
    myApp.mostfollowed();

    // Suggest friends for a user
    cout << "Suggested friends for Alice: ";
    myApp.suggestfriend("Alice");

    // Print group topics
    cout << "Group topics: " << endl;
    myApp.grouptopic();

    return 0;
}
