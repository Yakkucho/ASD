#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void add_first(Node*& head, int newData) {
    Node* baru = new Node;
    baru->data = newData;
    baru->next = head;
    head = baru;
}

void add_last(Node* head, int newData) {
    Node* baru = new Node;
    baru->data = newData;
    baru->next = nullptr;

    if (head == nullptr) {
        head = baru; 
        return;
    }

    Node* temp = head;
    while (temp->next != nullptr) {
        temp = temp->next;
    }
    temp->next = baru;
}


void printList(Node* head) {
    Node* temp = head;
    while (temp != nullptr) 
    {
        cout << temp->data;
        if (temp->next != nullptr) {
            cout << "-->";
        }
        temp = temp->next;
    }
    cout << endl;
}

bool contains(Node* head, int elemen) {
    Node* temp = head;
    while (temp != nullptr) {
        if (temp->data == elemen) {
            return true;  
        }
        temp = temp->next;
    }
    return false;
}

void replaceData(Node* head, int index, int newData) {
    Node* temp = head;
    for (int i = 0; i < index && temp != nullptr; i++) {
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "Index melebihi ukuran linked list" << endl;
        return;
    }

    temp->data = newData;
}

int index_of(Node* head, int elemen) {
    int index = 0;
    Node* temp = head;
    while (temp != nullptr) {
        if (temp->data == elemen) {
            return index;
        }
        temp = temp->next;
        index++;
    }
    return -1;
}

void insert_before_at(Node*& head, int elemen, int index) {
    Node* baru = new Node;
    baru->data = elemen;
    if (index == 0){
        add_first(head,elemen);
        return;
    }

    Node* temp = head;
    for (int i = 0; i < index -1; i++) {
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "Index melebihi ukuran linked list" << endl;
        return;
    }

    baru->next = temp->next;
    temp->next = baru;
}

void insert_after_at(Node* head, int newData, int index) {
    Node* baru = new Node;
    baru->data = newData;

    Node* temp = head;
    for (int i = 0; i < index; i++) {
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "Index melebihi ukuran linked list" << endl;
        return;
    }

    baru->next = temp->next;
    temp->next = baru;
}

void remove_first(Node*& head){
    Node* temp = head;
    head = head->next;
    delete temp;
}

void remove_last(Node*& head){
    Node* temp = head;
    Node* prev = nullptr;
    while (temp->next != nullptr){
        prev = temp;
        temp = temp->next;
    }
    delete temp;
    prev->next = nullptr;
}

void remove_at(Node*& head, int index) {
    if (head == nullptr) {
        cout << "Linked list kosong." << endl;
        return;
    }

    if (index == 0) {
        remove_first(head);
        return;
    }

    Node* temp = head;
    for (int i = 0; temp != nullptr && i < index - 1; i++) {
        temp = temp->next;
    }

    if (temp == nullptr || temp->next == nullptr) {
        cout << "Index melebihi ukuran linked list" << endl;
        return;
    }

    Node* nodeToDelete = temp->next;
    temp->next = temp->next->next;
    delete nodeToDelete;
}

int get(Node* head, int index) {
    Node* temp = head;


    for (int i = 0; i < index; i++) {
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "Index melebihi ukuran linked list" << endl;
        return -1;
    }

    return temp->data;
}

int size(Node* head) {
    int sizeOfNode = sizeof(int) + sizeof(Node*); 
    int totalSize = 0;
    Node* temp = head;
    while (temp != nullptr) {
        totalSize += sizeOfNode;
        temp = temp->next;
    }
    return totalSize;
}

int main() {
    Node* head = nullptr; // index dari head(node pertama) = 0
     

    add_first(head, 100);
    add_first(head, 200);
    add_first(head, 300);
    add_first(head, 400);

    add_last(head,500);
    add_first(head, 50);
    insert_after_at(head,250,index_of(head,200));

    printList(head);

    remove_first(head);
    remove_at(head, index_of(head, 300));
    remove_last(head);
    printList(head);
    cout << boolalpha << contains(head,422) << endl;
    cout << boolalpha << contains(head,250) << endl;
    cout << "Elemen dari index 3: " << get(head,3) << endl;
    cout << "Index dari elemen 200 : " << index_of(head,200) << endl;
    cout << "Size dari linked list : " << size(head) << " byte"<< endl;
    
    return 0;
}